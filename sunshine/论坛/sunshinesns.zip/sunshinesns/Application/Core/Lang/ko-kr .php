<?php 
 return array(
'_FOLLOWERS_' =>' 관심',
'_SUCCESS_' =>' 성공',
'_FAIL_' =>' 실패',
'_PLEASE_' =>' 주세요',
'_LOG_IN_' =>' 로그인',
'_CANCEL_' =>' 취소',

);