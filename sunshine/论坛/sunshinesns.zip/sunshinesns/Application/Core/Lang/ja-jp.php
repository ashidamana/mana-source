<?php 
 return array(
'_FOLLOWERS_' =>' 注目',
'_SUCCESS_' =>' 成功',
'_FAIL_' =>' 失敗',
'_PLEASE_' =>' してください',
'_LOG_IN_' =>' 登録',
'_CANCEL_' =>' キャンセル',

);