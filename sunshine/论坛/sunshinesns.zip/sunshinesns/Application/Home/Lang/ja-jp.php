<?php 
 return array(
'_ACTIVE_MEMBER_' =>' 会員として活躍',
'_NEW_MEMBER_' =>' 最新の会員',
'_DISCOVERY_' =>' 発見',
'_SQUARE_' =>' 広場',
'_ERROR_WEBSITE_CLOSED_' =>' サイトは閉鎖する、訪問～後にしてください',
'_DAM_' =>' 指定がないプラグインの名称、コントローラや操作！',
'_POST_HOT_' =>' 人気スレ',
'_BLOCK_' =>' プレート',
'_ALL_SITE_' =>' 全站',
'_FORUM_BLOCK_' =>' フォーラムプレート',
'_POST_' =>' 招待状',


);