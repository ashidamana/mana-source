<?php 
 return array(
'_ACTIVE_MEMBER_' =>' Active member',
'_NEW_MEMBER_' =>' Newest member',
'_DISCOVERY_' =>' Found',
'_SQUARE_' =>' Square',
'_ERROR_WEBSITE_CLOSED_' =>' Site has been closed, please visit later.',
'_DAM_' =>' No controller or operation is specified!',
'_POST_HOT_' =>' Popular posts',
'_BLOCK_' =>' Section',
'_ALL_SITE_' =>' Total station',
'_FORUM_BLOCK_' =>' Forum plate',
'_POST_' =>' Post',


);