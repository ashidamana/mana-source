<?php 
 return array(
'_ACTIVE_MEMBER_' =>' 활발하다 회원',
'_NEW_MEMBER_' =>' 최신 회원',
'_DISCOVERY_' =>' 발견',
'_SQUARE_' =>' 광장',
'_ERROR_WEBSITE_CLOSED_' =>' 사이트 이미 닫혔으며, 좀 이따 방문 ~',
'_DAM_' =>' 지정되지 플러그인 이름, 제어 장치 혹은 운영!',
'_POST_HOT_' =>' 인기 贴子',
'_BLOCK_' =>' 땅덩이가',
'_ALL_SITE_' =>' 全站',
'_FORUM_BLOCK_' =>' 포럼 분야.',
'_POST_' =>' 글',


);