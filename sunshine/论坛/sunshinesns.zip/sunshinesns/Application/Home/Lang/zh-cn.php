<?php
return array(

//    People__BLOCK_
    '_ACTIVE_MEMBER_'=>'活跃会员',
    '_NEW_MEMBER_'=>'最新会员',


    '_DISCOVERY_'=>'发现',
    '_SQUARE_'=>'广场',
    '_ERROR_WEBSITE_CLOSED_'=>'站点已经关闭，请稍后访问~',
    '_DAM_'=>'没有指定插件名称，控制器或操作！',

//    forum
    '_POST_HOT_'=>'热门贴子',
    '_BLOCK_'=>'版块',
    '_ALL_SITE_'=>'全站',
    '_FORUM_BLOCK_'=>'论坛板块',
    '_POST_'=>'帖子',



);