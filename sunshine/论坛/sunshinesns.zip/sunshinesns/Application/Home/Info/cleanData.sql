DROP TABLE IF EXISTS `ocenter_cat_data`;
DROP TABLE IF EXISTS `ocenter_cat_entity`;
DROP TABLE IF EXISTS `ocenter_cat_fav`;
DROP TABLE IF EXISTS `ocenter_cat_field`;
DROP TABLE IF EXISTS `ocenter_cat_info`;
DROP TABLE IF EXISTS `ocenter_cat_rate`;
DROP TABLE IF EXISTS `ocenter_cat_read`;
DROP TABLE IF EXISTS `ocenter_cat_send`;
