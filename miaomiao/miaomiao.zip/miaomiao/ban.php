<!DOCTYPE html>
<html>
    <head>
        <title>苗苗宝贝の看板</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>        
        <meta name="author" content="Flyer Angel"/>
        <link rel="shortcut icon" type="image/x-icon" href="http://7xnnpw.com1.z0.glb.clouddn.com/data/attachment/site/miaomiao.ico" />
        <link rel="stylesheet" href="http://7xnnpw.com1.z0.glb.clouddn.com/data/attachment/site/mm_kanban.css" type="text/css" />
        <!--<link rel="stylesheet" href="./style/kanban.css" type="text/css" />-->
    </head>
    <body>
        <script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
        <script type="text/javascript">
//            实现div垂直居中
            $(window).resize(function() {
                $(".banci").css({
                    position: "absolute",
                    left: ($(window).width() - $(".banci").outerWidth()) / 2,
                    top: ($(window).height() - $(".banci").outerHeight()) / 2
                });
            });
            $(function() {
//                alert(($(window).width()));
                $(window).resize();
            });
        </script>

        <div class="bg"><img src="http://7xnnpw.com1.z0.glb.clouddn.com/data/attachment/site/mmbg.gif"></div>
        <div class="banci">
            <p class="title">苗苗宝贝の看板</p>
            <?php
//    设置默认时区为北京时间
            date_default_timezone_set('PRC');
            error_reporting(E_ALL ^ E_NOTICE);
            getBanci();

            function getBanci() {
                $startdate = strtotime("20160407");
                $enddate = isset($_GET['d']) ? strtotime($_GET['d']) : strtotime(date("Ymd"));
//        $enddate = strtotime("20160425");
                $days = round(($enddate - $startdate) / 86400);
                $bzBanci = "白";
//                分界时间点
                $boundary = "0409";
                $today = isset($_GET['d']) ? substr($_GET['d'], 4, 4) : date("md");
//                echo $today;
                if ($today >= $boundary) {
//                    采用新时间（夏季）
                    $banci = array(
                        0 => array(0 => "白", 1 => "上班时间：07:40-11:00,14:00-17:30"),
                        1 => array(0 => "白", 1 => "上班时间：07:40-11:00,14:00-17:30"),
                        2 => array(0 => "120", 1 => "上班时间：全天，在15:30-17:30休息"),
                        3 => array(0 => "中夜", 1 => "上班时间：11:00-14:00,17:30-次日07:40"),
                        4 => array(0 => "休息", 1 => "今天不上班，宝贝可以多休息，或者粗去逛逛，也可以想我哦"),
                    );
                } else {
//                    采用新时间（冬季）
                    $banci = array(
                        0 => array(0 => "白", 1 => "上班时间：07:30-11:00,13:45-17:00"),
                        1 => array(0 => "白", 1 => "上班时间：07:30-11:00,13:45-17:00"),
                        2 => array(0 => "120", 1 => "上班时间：全天，在15:30-17:00休息"),
                        3 => array(0 => "中夜", 1 => "上班时间：11:00-13:45,17:00-次日07:30"),
                        4 => array(0 => "休息", 1 => "今天不上班，宝贝可以多休息，或者粗去逛逛，也可以想我哦"),
                    );
                }


                $care = array(
                    0 => "~(^_^)~最爱的苗苗宝贝辛苦了",
                    1 => "(=￣ω￣=)宝贝记得要照顾好自己",
                    2 => "(＠￣︶￣＠)宝贝今天工作累吗？给你肩膀靠",
                    3 => "(=@__@=)苗苗宝贝，我好想你，你也想我不？",
                );
                $careXiuxi = array(
                    0 => "(*^__^*) 宝贝今天有去哪玩不？",
                    1 => "(☆~☆)宝贝今天过的开心不？",
                    2 => "( *^_^* ) 宝贝你有没有感到一种幸福感来袭?",
                    3 => "( ＠^^＠) 苗苗宝贝，我好喜欢你",
                    4 => "( # ^.^ # )苗苗宝贝，我好想你",
                    4 => "(*∩_∩*)苗苗宝贝，我好爱你",
                    5 => "(*^﹏^*)苗苗宝贝，我想每天都能对你吻安",
                );
                $index = $days % 5;
                if ($index == 4) {
                    $hint = "休息</p><p class='ban_info'>" . $banci[$index][1] . "</p><p class='want_to_say'>今天我想说：" . $careXiuxi[rand(0, 5)] . "</p>";
                } else {
                    $hint = "上" . $banci[$index][0] . "班</p><p style='font-family:hyxy'>" . $banci[$index][1] . "</p><p class='want_to_say'>今天我想说：" . $care[rand(0, 3)] . "</p>";
                }
                $date = isset($_GET['d']) ? date("Y年m月d日", strtotime($_GET['d'])) : date("Y年m月d日");
                echo "<p style='font-family:hyxy'>今天是" . $date . ",苗苗宝贝" . $hint;
            }
            ?>
        </div>
    </body>
</html>